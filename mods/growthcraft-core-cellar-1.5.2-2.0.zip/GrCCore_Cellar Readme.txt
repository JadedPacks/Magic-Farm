GrowthCraft Core: Cellar 2.0
===========================

------------
Requirements
------------
MineCraft 1.5.2
Forge 7.8.0
GrowthCraft Core 2.0

----------------
Default IDs Used
----------------
Blocks : 499, 498, 497
Villager : 7

----------------
Vanilla Edits
----------------
x

------------
ZIP Contents
------------
grc_core_cellar_logo.png

growthcraft/core/cellar
>> ClientProxyGrCCoreCellar.class
>> CommonProxyGrCCoreCellar.class
>> GrCCellarManager.class
>> mod_GrowthCraftCoreCellar.class

growthcraft/core/cellar/blocks
>> BlockGrCBrewBarrel.class
>> BlockGrCCauldron.class
>> BlockGrCFruitPress.class
>> BlockGrCFruitPressBin.class
>> BlockGrCFruitPressBinBase.class

growthcraft/core/cellar/containers
>> ContainerGrCBrewBarrel.class
>> GuiGrCBrewBarrel.class
>> GuiHandlerGrCBrewBarrel.class
>> TileEntityGrCBrewBarrel.class

growthcraft/core/cellar/items
>> ItemGrCBoozeBase.class
>> ItemGrCBucketOfBooze.class

growthcraft/core/cellar/renders
>> RenderGrCBrewBarrel.class
>> RenderGrCCauldron.class
>> RenderGrCFruitPress.class
>> RenderGrCFruitPressBin.class

growthcraft/core/cellar/village
>> ComponentVillageGrCBar.class
>> VillageHandlerGrCBar.class

mods/core/textures/blocks
>> blockBlank.png
>> blockBrewBarrelLid.png
>> blockBrewBarrelSides.png
>> blockPressBinBottom.png
>> blockPressBinSides.png
>> blockPressBinTop.png
>> blockPressSide.png

mods/core/textures/entities
>> brewer.png

mods/core/textures/guis
>> guiBrewBarrel.png

mods/core/textures/items
>> itemBooze.png
>> itemGooze_Contents.png
>> itemBucket_Contents.png

mcmod.info

------------
Installation
------------
1. Install the requirements.
3. Place "growthcraft-core-cellar-1.5.2-2.0" to your mods folder.

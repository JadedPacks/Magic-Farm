GrowthCraft Grapes 5.0
======================

-----------
Requirement
-----------
MineCraft 1.5.2
Forge 7.8.0
GrowthCraft Core 2.0
GrowthCraft Core: Booze 2.0

----------------
Default IDs Used
----------------
Blocks : 502, 503, 504
Items  : 5004, 5005, 5006,5007, 5008

----------------
Vanilla Edits
----------------
x

------------
ZIP Contents
------------
grc_grapes_logo.png

growthcraft/grapes
>> BlockGrCGrapeA.class
>> BlockGrCGrapeB.class
>> BlockGrCGrapePressBin.class
>> ClientProxyGrCGrapes.class
>> CommonProxyGrCGrapes.class
>> ComponentVillageGrCGrapes.class
>> ItemGrCGrapeBushel.class
>> itemGrCGrapes.class
>> itemGrCGrapeSeeds.class
>> ItemGrCGrapeWine.class
>> mod_GrowthCraftGrapes.class
>> RenderGrCGrapePressBin.class
>> RenderGrCGrapes.class
>> VillageHandlerGrCGrapes.class

mods/grapes/textures/blocks
>> blockBlank.png
>> blockPressBinGrapes.png
>> blockTrunk0.png
>> blockTrunk1.png
>> blockTrunk2.png
>> blockVine0.png
>> blockVine1.png
>> blockVine2.png

mods/grapes/textures/items
>> itemCutting.png
>> itemGrapeBushel.png
>> itemGrapes.png

mcmod.info

------------
Installation
------------
1. Install the requirements.
4. Place "growthcraft-grapes-1.5.2-5.0" to your mods folder.

GrowthCraft Core 2.0
======================

------------
Requirements
------------
MineCraft 1.5.2
Forge 7.8.0

----------------
Default IDs Used
----------------
x

----------------
Vanilla Edits
----------------
x

------------
ZIP Contents
------------
grc_core_logo.png

growthcraft/core
>> CreativeTabGrCCore.class
>> mod_GrowthCraftCore.class

growthcraft/core/items
>> ItemGrCFood.class
>> ItemGrCSeeds.class

mods/core/textures/blocks
>> blockLiquidBlob.png
>> blockLiquidBlob.txt
>> blockLiquidSmooth.png
>> blockLiquidSmooth.txt

mcmod.info

------------
Installation
------------
1. Install the requirements.
2. Place "growthcraft-core-1.5.2-2.0" to your mods folder.

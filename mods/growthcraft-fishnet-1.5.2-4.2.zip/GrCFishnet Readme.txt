GrowthCraft Fishnet 4.2
=======================

------------
Requirements
------------
MineCraft 1.5.2
Forge 7.8.0

----------------
Default IDs Used
----------------
Blocks : 508

----------------
Vanilla Edits
----------------
x

------------
ZIP Contents
------------
grc_fishnet_logo.png

growthcraft/fishnet
>> BlockGrCFishnet.class
>> ContainerGrCFishnet.class
>> GuiGrCFishnet.class
>> GuiHandlerGrCFishnet.class
>> mod_GrowthCraftFishnet.class
>> TileEntityGrCFishnet.class

mods/fishnet/textures/blocks
>> blockFishnet.png

mods/fishnet/textures/gui
>> guiFishnet.png

mcmod.info

------------
Installation
------------
1. Install the requirements.
2. Place "growthcraft-fishnet-1.5.2-4.2" to your mods folder.

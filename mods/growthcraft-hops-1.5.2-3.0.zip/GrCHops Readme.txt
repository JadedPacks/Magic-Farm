GrowthCraft Hops 3.0
====================

------------
Requirements
------------
MineCraft 1.5.2
Forge 7.8.0
GrowthCraft Core 2.0
GrowthCraft Core: Booze 2.0

----------------
Default IDs Used
----------------
Blocks : 505, 506, 507
Items  : 5009, 5010, 5011, 5012, 5013, 5014

----------------
Vanilla Edits
----------------
x

------------
ZIP Contents
------------
grc_hops_logo.png

growthcraft/hops
>> BlockGrCHopA.class
>> BlockGrCHopB.class
>> BlockGrCHopCauldron.class
>> ClientProxyGrCHops.class
>> CommonProxyGrCHops.class
>> ComponentVillageGrCHops.class
>> ItemGrCHopAle.class
>> ItemGrCHopSeeds.class
>> ItemGrCWheatBushel.class
>> mod_GrowthCraftHops.class
>> RenderGrCHopCauldron.class
>> RenderGrCHop.class
>> VillageHandlerGrCHops.class

mods/hops/textures/blocks
>> blockAleCauldronHops.png
>> blockAleCauldronWheat1.png
>> blockAleCauldronWheat2.png
>> blockAleCauldronWheat3.png
>> blockFruitBottoms.png
>> blockFruitSides.png
>> blockFruitTops.png
>> blockVine0.png
>> blockVine1.png
>> blockVine2.png

mods/hops/textures/items
>> itemHopBushel.png
>> itemHops.png
>> itemRhizome.png
>> itemWheatBushel.png

mcmod.info

------------
Installation
------------
1. Install the requirements.
4. Place "growthcraft-hops-1.5.2-3.0" to your mods folder.
